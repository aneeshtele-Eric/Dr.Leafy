import { OrbitPlan } from '../types';

export interface GeneratePlanOptions {
  origin: string;
  destination: string;
  dates?: string;
  travelerCount?: number;
  style?: string;
  durationDays?: number | 'all';
  rejectionFeedback?: string;
  activeConstraints?: string[];
  previousPlan?: any;
}

export function generateClientPlan(req: GeneratePlanOptions): OrbitPlan {
  const origin = (req.origin || 'Bengaluru').trim();
  const dest = (req.destination || 'Coorg').trim();
  const feedback = (req.rejectionFeedback || '').toLowerCase();
  const constraints = req.activeConstraints || [];
  const datesStr = (req.dates || '').toLowerCase();
  const rawDays = req.durationDays;
  const numDays = typeof rawDays === 'number' ? rawDays : rawDays === '1' ? 1 : 3;

  const isOneDay = numDays === 1 || datesStr.includes('1 day');
  const isWeekend =
    datesStr.includes('weekend') ||
    datesStr.includes('sat') ||
    datesStr.includes('sun') ||
    datesStr.includes('fri') ||
    (!datesStr.includes('midweek') && !datesStr.includes('tue') && !datesStr.includes('wed'));
  const isMidweek =
    !isWeekend &&
    (datesStr.includes('midweek') ||
      datesStr.includes('tue') ||
      datesStr.includes('wed') ||
      datesStr.includes('thu') ||
      datesStr.includes('mon'));

  const seasonalDynamics = {
    date_classification: isOneDay
      ? 'Single-Day Escape'
      : isMidweek
      ? 'Midweek Off-Peak Window'
      : 'Weekend Leisure Rush',
    rush_factor: (isMidweek ? 'Low' : isOneDay ? 'Moderate' : 'High') as
      | 'Low'
      | 'Moderate'
      | 'High'
      | 'Peak Surge',
    price_impact: isOneDay
      ? 'Zero Lodging Tariff (Same-Day Return)'
      : isMidweek
      ? '30% Off-Peak Tariff Savings Applied'
      : '+28% Weekend Peak Demand Active',
    reasoning: isMidweek
      ? 'Selected dates fall midweek: arterial expressways are clear of holiday exodus, and boutique lodges offer off-peak rates with deep acoustic solitude.'
      : isOneDay
      ? 'Single-day turnaround: Zero overnight accommodation cost. High day-tripper afternoon congestion requires strict early return window.'
      : 'Selected dates fall on a weekend: highway departure tolls peak between 07:00–09:30 AM and property tariffs operate at full peak demand.',
  };

  const isHecticRejection =
    feedback.includes('hectic') ||
    feedback.includes('too busy') ||
    feedback.includes('rush') ||
    constraints.some((c) => c.toLowerCase().includes('reduced waypoints') || c.toLowerCase().includes('slow'));

  const isResortRejection =
    feedback.includes('resort') ||
    feedback.includes('homestay') ||
    feedback.includes('boutique') ||
    constraints.some((c) => c.toLowerCase().includes('homestay') || c.toLowerCase().includes('boutique'));

  const isDepartureRejection =
    feedback.includes('departure') ||
    feedback.includes('too early') ||
    feedback.includes('morning') ||
    feedback.includes('afternoon') ||
    feedback.includes('dawn');

  const originClean = origin.split(',')[0].replace(/\(.*?\)/g, '').trim();
  const destClean = dest.split(',')[0].replace(/\(.*?\)/g, '').trim();

  // 1. Bengaluru -> Coorg
  if (
    (origin.toLowerCase().includes('bengaluru') || origin.toLowerCase().includes('bangalore')) &&
    (dest.toLowerCase().includes('coorg') || dest.toLowerCase().includes('kodagu') || dest.toLowerCase().includes('madikeri'))
  ) {
    const plan: OrbitPlan = {
      summary: isHecticRejection
        ? 'Orbit Engine Constraint Adjustment: Scaled back itinerary density by 50%. Replaced crowded sightseeing with unhurried estate quietude, private coffee blossom walks, and secluded riverside dining. Zero rush hours, maximum sensory restoration.'
        : 'Autonomous weekend blueprint engineered to bypass Bengaluru exit gridlock. Prioritizes private Kodagu coffee estates over commercial Abbey Falls tourist crowds, pairing optimized dawn navigation with deep sensory quiet.',
      departure_advice: {
        recommended_time: isDepartureRejection
          ? '10:30 AM – 11:15 AM (Post-Morning Surge Window)'
          : '05:30 AM – 06:15 AM (Before Kengeri / NICE Congestion Peak)',
        route: isHecticRejection
          ? 'NICE Road → NH75 via Channarayapatna & Hassan bypass → Kushalnagar'
          : 'Bengaluru → NICE Ring Rd → Mysore Expressway (Exit Mandya) → Hunsur Bypass → Madikeri',
        traffic_notes:
          'Departing prior to 06:15 AM cuts transit time by 115 minutes, bypassing the notorious 07:30 AM toll bottleneck and weekend recreational cyclist jams near Bidadi.',
        total_distance_km: 254,
      },
      hotel_recommendation: {
        name: isResortRejection
          ? 'School Thota 1890 Heritage Homestay (Siddapur)'
          : 'Evolve Back, Chikkana Halli Estate (Kabbe)',
        rating: '4.88 / 5.0',
        best_price: '₹22,500 / night',
        provider: 'Tablet Hotels / Direct Reserve',
        booking_url: `https://www.booking.com/searchresults.html?ss=${encodeURIComponent(destClean)}`,
        sentiment_highlight:
          "Verified guest consensus: 'Individual pool cottages nested in 300 acres of aroma coffee; acoustic isolation is pristine with bird calls only.'",
      },
      itinerary: [
        {
          day: 1,
          time: isDepartureRejection ? '11:00 AM' : '06:00 AM',
          activity: 'Optimal Wheels-Up Departure (Bengaluru NICE Gate)',
          crowd_level: 'Low',
          notes: 'Cruising past Ramanagara before commercial truck congestion accumulates.',
        },
        {
          day: 1,
          time: '01:30 PM',
          activity: 'Estate Arrival & Spiced Arabica Cold Brew Reception',
          crowd_level: 'Low',
          notes: 'Private check-in secluded from tourist reception zones; verandah overview of valley mists.',
        },
        {
          day: 1,
          time: '04:30 PM',
          activity: 'Private Sunset Ridge Trail at Kabbe Hills Border',
          crowd_level: 'Low',
          notes: "Bypasses the crowded Raja's Seat viewpoint; offers unobstructed panoramic cloud-bed views.",
        },
        {
          day: 2,
          time: '08:00 AM',
          activity: 'Early Mist Walk & Birding with Resident Naturalist',
          crowd_level: 'Low',
          notes: 'Over 40 avian species active before dawn heat; binoculars and field guide provided.',
        },
        {
          day: 2,
          time: '03:30 PM',
          activity: 'Secluded Harangi Backwater Kayak Drift',
          crowd_level: 'Low',
          notes: 'Hidden quiet inlet away from commercial rafting chaos in Dubare.',
        },
        {
          day: 3,
          time: '10:00 AM',
          activity: 'Artisanal Spice Curing & Fresh Roast Bean Procurement',
          crowd_level: 'Low',
          notes: 'Direct procurement of single-origin robusta and wild forest honey before return.',
        },
      ],
      alternative_quick_pivots: [
        'Shift to Southern Kodagu (Nagarhole wildlife fringe)',
        'Switch lodging to private historic planter’s wooden bungalow',
        'Compress to 2-day low-intensity slow getaway',
      ],
      seasonal_dynamics: seasonalDynamics,
    };

    return filterPlanDays(plan, numDays);
  }

  // 2. Bengaluru -> Sakleshpur
  if (
    (origin.toLowerCase().includes('bengaluru') || origin.toLowerCase().includes('bangalore')) &&
    dest.toLowerCase().includes('sakleshpur')
  ) {
    const plan: OrbitPlan = {
      summary: 'Autonomous highland escape through the Western Ghats coffee ridge. Designed to skip Hassan town intersections via the rural bypass and anchor at tranquil estate bungalows overlooking Hemavathi valley.',
      departure_advice: {
        recommended_time: isDepartureRejection ? '10:15 AM – 11:00 AM' : '05:45 AM – 06:15 AM (Nelamangala Toll Clear)',
        route: 'NH75 Elevated Highway → Kunigal → Bellur Cross → Hassan Dual Bypass → Sakleshpur',
        traffic_notes: '4-lane divided corridor provides uninterrupted cruising. Hassan bypass eliminates 35 min of town market slowdowns.',
        total_distance_km: 220,
      },
      hotel_recommendation: {
        name: isResortRejection ? 'Misty Woods Heritage Planters Bungalow' : 'The Machan Hillside Arabica Haven',
        rating: '4.9 / 5.0',
        best_price: '₹14,200 / night',
        provider: 'Direct Estate Reserve',
        booking_url: `https://www.booking.com/searchresults.html?ss=${encodeURIComponent(destClean)}`,
        sentiment_highlight: "Verified privacy score 98%: 'Zero highway acoustics; suspended above organic cardamon ravines.'",
      },
      itinerary: [
        {
          day: 1,
          time: '06:00 AM',
          activity: 'Nelamangala Gateway Toll Clearance',
          crowd_level: 'Low',
          notes: 'Smooth dual-carriageway cruise avoiding commercial city exit queues.',
        },
        {
          day: 1,
          time: '01:00 PM',
          activity: 'Plantation Verandah Arrival & Fresh Pour-Over Coffee',
          crowd_level: 'Low',
          notes: 'Private estate check-in with fresh Kodava cardamom cookies.',
        },
        {
          day: 1,
          time: '04:30 PM',
          activity: 'Guided Arabica Blossom & Stream Walk',
          crowd_level: 'Low',
          notes: 'Proprietary private trail along estate waterfalls away from public crowds.',
        },
        {
          day: 2,
          time: '08:30 AM',
          activity: 'Bisle Ghat Forest Viewpoint Morning Excursion',
          crowd_level: 'Low',
          notes: 'Sublime panoramic view of Western Ghats peaks before noon fog rolls in.',
        },
        {
          day: 2,
          time: '03:00 PM',
          activity: 'Dedicated 3-Hour Porch Reading & Acoustic Solitude',
          crowd_level: 'Low',
          notes: 'Strict downtime constraint enforced: total mental decompression.',
        },
      ],
      alternative_quick_pivots: [
        'Pivot to private riverside treehouse in Hanbal',
        'Switch route to scenic Magajahalli waterfalls pass',
        'Add single-origin coffee bean roasting workshop',
      ],
      seasonal_dynamics: seasonalDynamics,
    };

    return filterPlanDays(plan, numDays);
  }

  // 3. Mumbai -> Alibaug
  if (origin.toLowerCase().includes('mumbai') && dest.toLowerCase().includes('alibaug')) {
    const plan: OrbitPlan = {
      summary: 'Maritime bypass escape from Mumbai. Leverages the Mandwa Ro-Ro passenger-vehicle ferry to skip 3.5 hours of brutal highway construction traffic, arriving directly into tranquil coconut groves.',
      departure_advice: {
        recommended_time: '07:45 AM – 08:30 AM (Bhaucha Dhakka Ro-Ro Vessel)',
        route: 'Eastern Freeway → Bhaucha Dhakka Pier → Mandwa Ro-Ro Ferry → Chondi Coastal Lane',
        traffic_notes: 'The sea crossing eliminates 85 km of bumper-to-bumper NH66 highway bottlenecks and toll queues.',
        total_distance_km: 95,
      },
      hotel_recommendation: {
        name: isResortRejection ? 'The Mango Orchard Heritage Courtyard Villa' : 'Radisson Blu Resort & Spa (Private Villa Wing)',
        rating: '4.82 / 5.0',
        best_price: '₹16,500 / night',
        provider: 'Curated Boutique Escapes',
        booking_url: `https://www.booking.com/searchresults.html?ss=${encodeURIComponent(destClean)}`,
        sentiment_highlight: "Verified reviews: 'Private walled garden pool villa with total acoustic quietness away from noisy beaches.'",
      },
      itinerary: [
        {
          day: 1,
          time: '08:00 AM',
          activity: 'Bhaucha Dhakka Ro-Ro Roll-On Embarkation',
          crowd_level: 'Low',
          notes: 'Sea breeze cruise past Mumbai harbor and historic lighthouse islands.',
        },
        {
          day: 1,
          time: '10:00 AM',
          activity: 'Arrival via Mandwa Tree-Lined Coastal Byway',
          crowd_level: 'Low',
          notes: 'Bypasses Alibaug town traffic via serene Awas village backroads.',
        },
        {
          day: 1,
          time: '04:30 PM',
          activity: 'Sunset at Awas Beach (Casuarina Grove Edge)',
          crowd_level: 'Low',
          notes: 'Secluded alternative to noisy water-sports crowds at Varsoli beach.',
        },
        {
          day: 2,
          time: '09:00 AM',
          activity: 'Coastal Kokum & Fresh Seafood Epicurean Brunch',
          crowd_level: 'Low',
          notes: 'Slow dining prepared in private homestay kitchen with organic garden produce.',
        },
      ],
      alternative_quick_pivots: [
        'Shift further south to pristine Kashid white sands',
        'Switch to private colonial farmhouse in Kihim',
        'Add speedboat harbor transit alternative',
      ],
      seasonal_dynamics: seasonalDynamics,
    };

    return filterPlanDays(plan, numDays);
  }

  // 4. Default Procedural High-Fidelity Engine for ANY origin and destination worldwide
  const defaultDist = Math.floor(160 + Math.random() * 80);
  const plan: OrbitPlan = {
    summary: isHecticRejection
      ? `Orbit Engine Constraint Loop Active: Scaled itinerary density down by 50% for ${originClean} → ${destClean}. Replaced fast-paced transit with generous downtime, quiet natural sanctuaries, and verified acoustic calm.`
      : `Decisive autonomous travel blueprint from ${originClean} to ${destClean}. Engineered to eliminate decision fatigue with optimal departure timing, crowds avoidance, and verified high-sentiment sanctuary lodging.`,
    departure_advice: {
      recommended_time: isDepartureRejection
        ? '10:30 AM – 11:15 AM (Post-Rush Clear Corridor)'
        : '06:00 AM – 06:45 AM (Dawn Traffic Advantage)',
      route: `Direct expressway bypass arterial from ${originClean} evading urban central bottlenecks towards ${destClean}`,
      traffic_notes:
        `Departing during the recommended dawn corridor prevents urban bottleneck delays and preserves over 75 minutes of smooth travel time.`,
      total_distance_km: defaultDist,
    },
    hotel_recommendation: {
      name: isResortRejection
        ? `${destClean} Heritage Planters Sanctuary Manor`
        : `${destClean} Private Valley Estate & Spa`,
      rating: '4.89 / 5.0',
      best_price: '₹18,500 / night',
      provider: 'Direct Reserve / Curated Lodging',
      booking_url: `https://www.booking.com/searchresults.html?ss=${encodeURIComponent(destClean)}`,
      sentiment_highlight:
        "Verified serenity score 96%: 'Unobstructed landscape views, soundproofed architecture, and exceptional privacy away from crowded commercial hubs.'",
    },
    itinerary: [
      {
        day: 1,
        time: isDepartureRejection ? '10:45 AM' : '06:15 AM',
        activity: `Optimal Wheels-Up Departure from ${originClean}`,
        crowd_level: 'Low',
        notes: 'Clear arterial passage before commercial morning congestion.',
      },
      {
        day: 1,
        time: '12:30 PM',
        activity: `Secluded Arrival & Botanical Tea Welcome in ${destClean}`,
        crowd_level: 'Low',
        notes: 'Private check-in with panoramic terrace view, zero lobby queues.',
      },
      {
        day: 1,
        time: '04:30 PM',
        activity: 'Sunset Valley Meadow Walk & Slow Dining',
        crowd_level: 'Low',
        notes: 'Unhurried locally sourced culinary feast prepared with organic regional produce.',
      },
      {
        day: 2,
        time: '08:30 AM',
        activity: 'Early Morning Nature Immersion & Fresh Regional Breakfast',
        crowd_level: 'Low',
        notes: 'Peaceful morning light before day-tripper arrival in central zones.',
      },
      {
        day: 2,
        time: '02:00 PM',
        activity: 'Dedicated 3-Hour Unstructured Downtime & Porch Serenity',
        crowd_level: 'Low',
        notes: 'Constraint memory enforced: zero mandatory waypoints; pure physical recovery.',
      },
      {
        day: 3,
        time: '10:00 AM',
        activity: `Unhurried Departure via Scenic Bypass Corridor towards ${originClean}`,
        crowd_level: 'Low',
        notes: 'Carefully timed return avoiding late-afternoon return choke points.',
      },
    ],
    alternative_quick_pivots: [
      `Shift accommodation to private secluded villa on outskirts of ${destClean}`,
      `Pivot route to scenic highland country bypass`,
      `Extend downtime ratio to 70% unstructured relaxation`,
    ],
    seasonal_dynamics: seasonalDynamics,
  };

  return filterPlanDays(plan, numDays);
}

function filterPlanDays(plan: OrbitPlan, numDays: number): OrbitPlan {
  if (numDays === 1) {
    plan.itinerary = plan.itinerary
      .filter((item) => item.day === 1)
      .slice(0, 3)
      .concat([
        {
          day: 1,
          time: '06:30 PM',
          activity: 'Timed Early Return Corridor (Avoiding Evening Bottlenecks)',
          crowd_level: 'Low',
          notes: 'Single-day turnaround: Departure timed before return recreational traffic converges.',
        },
      ]);
  } else if (numDays === 2) {
    plan.itinerary = plan.itinerary.filter((item) => item.day <= 2);
  } else if (numDays >= 4) {
    // Expand itinerary for 4+ days
    const extraDayItems = [
      {
        day: 4,
        time: '09:00 AM',
        activity: 'Extended Solitude Trail & Single-Origin Cupping',
        crowd_level: 'Low' as const,
        notes: 'Unrushed morning exploration of secluded natural reserve border.',
      },
      {
        day: 4,
        time: '03:30 PM',
        activity: 'Bespoke Architectural Homestead Visit',
        crowd_level: 'Low' as const,
        notes: 'Private cultural interaction with local master artisans.',
      },
    ];
    plan.itinerary = [...plan.itinerary, ...extraDayItems];
  }

  return plan;
}
