import React, { useState, useRef, useEffect, useMemo } from 'react';
import { MapPin, Navigation, Search, X, Check, Globe, Loader2 } from 'lucide-react';
import { POPULAR_PLACES, PlaceItem } from '../data/places';

interface PlaceAutocompleteProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  iconType?: 'origin' | 'destination';
  className?: string;
}

export const PlaceAutocomplete: React.FC<PlaceAutocompleteProps> = ({
  label,
  value,
  onChange,
  placeholder = 'Type place name...',
  iconType = 'origin',
  className = '',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(0);
  const [liveSuggestions, setLiveSuggestions] = useState<PlaceItem[]>([]);
  const [isSearchingLive, setIsSearchingLive] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Normalize current query
  const query = value.trim().toLowerCase();

  // Instant local suggestions from expanded static database
  const localSuggestions = useMemo(() => {
    if (!query) {
      return POPULAR_PLACES.filter((p) =>
        iconType === 'origin'
          ? p.type === 'origin' || p.type === 'both'
          : p.type === 'destination' || p.type === 'both'
      ).slice(0, 8);
    }

    return POPULAR_PLACES.filter((p) => {
      const matchName = p.name.toLowerCase().includes(query);
      const matchRegion = p.region.toLowerCase().includes(query);
      const matchCountry = p.country.toLowerCase().includes(query);
      const matchTag = p.tag.toLowerCase().includes(query);
      return matchName || matchRegion || matchCountry || matchTag;
    }).slice(0, 8);
  }, [query, iconType]);

  // Live Geocoding API fetch (debounced) for global searchability
  useEffect(() => {
    if (!query || query.length < 2) {
      setLiveSuggestions([]);
      setIsSearchingLive(false);
      return;
    }

    // Cancel previous fetch
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    const controller = new AbortController();
    abortControllerRef.current = controller;

    const timer = setTimeout(async () => {
      try {
        setIsSearchingLive(true);
        const cleanQuery = query.split(',')[0].replace(/\(.*?\)/g, '').trim();
        const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cleanQuery)}&count=8&language=en&format=json`;
        const res = await fetch(url, { signal: controller.signal });
        if (res.ok) {
          const json = await res.json();
          if (Array.isArray(json.results) && json.results.length > 0) {
            const mapped: PlaceItem[] = json.results.map((r: any) => ({
              id: `geo-${r.id || Math.random()}`,
              name: r.name,
              region: r.admin1 || r.admin2 || r.country || '',
              country: r.country || 'Global',
              type: 'both',
              tag: `${r.country || 'Global'} · Elevation ~${Math.round(r.elevation || 0)}m`,
              lat: r.latitude,
              lon: r.longitude,
            }));

            // Filter out exact duplicates that already appear in localSuggestions
            const existingNames = new Set(localSuggestions.map((s) => s.name.toLowerCase()));
            const filteredLive = mapped.filter((m) => !existingNames.has(m.name.toLowerCase()));
            setLiveSuggestions(filteredLive);
          } else {
            setLiveSuggestions([]);
          }
        }
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          setLiveSuggestions([]);
        }
      } finally {
        setIsSearchingLive(false);
      }
    }, 220);

    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [query, localSuggestions]);

  // Combined suggestions
  const combinedSuggestions = useMemo(() => {
    if (!query) return localSuggestions;
    // Combine local matches first, followed by live geocoding results
    const combined = [...localSuggestions, ...liveSuggestions];
    // Deduplicate by name + country
    const seen = new Set<string>();
    return combined.filter((item) => {
      const key = `${item.name.toLowerCase()}_${item.country.toLowerCase()}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    }).slice(0, 10);
  }, [localSuggestions, liveSuggestions, query]);

  // Click outside listener
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!isOpen) {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        setIsOpen(true);
        return;
      }
    }

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlightedIndex((prev) => (prev + 1) % Math.max(1, combinedSuggestions.length));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlightedIndex((prev) => (prev - 1 + combinedSuggestions.length) % Math.max(1, combinedSuggestions.length));
    } else if (e.key === 'Enter') {
      if (isOpen && combinedSuggestions.length > 0 && combinedSuggestions[highlightedIndex]) {
        e.preventDefault();
        handleSelect(combinedSuggestions[highlightedIndex]);
      }
    } else if (e.key === 'Escape') {
      setIsOpen(false);
    }
  };

  const handleSelect = (place: PlaceItem) => {
    const formatted = `${place.name}${place.region ? `, ${place.region}` : ''}, ${place.country}`;
    onChange(formatted);
    setIsOpen(false);
    inputRef.current?.blur();
  };

  const handleClear = (e: React.MouseEvent) => {
    e.stopPropagation();
    onChange('');
    setLiveSuggestions([]);
    setIsOpen(true);
    inputRef.current?.focus();
  };

  return (
    <div ref={containerRef} className={`relative ${className} ${isOpen ? 'z-30' : 'z-10'}`}>
      <label className="block text-[11px] font-semibold tracking-wider uppercase text-[#514538] mb-1.5 flex items-center justify-between">
        <span>{label}</span>
        {isSearchingLive && (
          <span className="text-[10px] text-[#865302] font-normal flex items-center gap-1 lowercase">
            <Loader2 className="w-2.5 h-2.5 animate-spin" />
            searching global atlas...
          </span>
        )}
      </label>

      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#865302]">
          {iconType === 'origin' ? (
            <MapPin className="w-4 h-4 text-[#865302]" />
          ) : (
            <Navigation className="w-4 h-4 text-[#865302]" />
          )}
        </div>

        <input
          ref={inputRef}
          type="text"
          value={value}
          onChange={(e) => {
            onChange(e.target.value);
            setIsOpen(true);
            setHighlightedIndex(0);
          }}
          onFocus={() => setIsOpen(true)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="w-full pl-10 pr-9 py-2.5 bg-white border border-[#E3D5C5] rounded-xl text-sm text-[#1E1B19] placeholder:text-[#837466]/60 focus:outline-none focus:ring-2 focus:ring-[#C88A3C]/40 focus:border-[#C88A3C] transition-all font-medium"
        />

        {value && (
          <button
            type="button"
            onClick={handleClear}
            className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#837466] hover:text-[#1E1B19]"
            title="Clear field"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Autocomplete Dropdown */}
      {isOpen && (
        <div className="absolute left-0 right-0 top-full mt-1.5 z-50 bg-white rounded-xl border border-[#E3D5C5] shadow-[0_12px_32px_-4px_rgba(44,38,35,0.14)] overflow-hidden animate-in fade-in zoom-in-95 duration-150">
          <div className="p-2 border-b border-[#E3D5C5]/60 bg-[#FAF2EE]/60 flex items-center justify-between text-[10px] font-semibold tracking-wider uppercase text-[#865302]">
            <span>
              {query
                ? `Search results for "${value}"`
                : iconType === 'origin'
                ? 'Frequent Origins & Metros'
                : 'Popular Sanctuaries & Destinations'}
            </span>
            <div className="flex items-center gap-2">
              {isSearchingLive && <Loader2 className="w-2.5 h-2.5 animate-spin text-[#865302]" />}
              <span className="text-[#837466] lowercase font-normal">
                {combinedSuggestions.length} places
              </span>
            </div>
          </div>

          <div className="max-h-72 overflow-y-auto divide-y divide-[#E3D5C5]/40 py-1">
            {combinedSuggestions.length === 0 ? (
              <div className="p-4 text-center text-xs text-[#837466]">
                <Globe className="w-4 h-4 mx-auto mb-1 text-[#C88A3C] opacity-70" />
                <span>
                  No exact preset match for "{value}". Orbit Engine will calculate routing dynamically using the typed location.
                </span>
              </div>
            ) : (
              combinedSuggestions.map((place, idx) => {
                const isSelected = value.toLowerCase().includes(place.name.toLowerCase());
                const isHighlighted = idx === highlightedIndex;
                const isLive = place.id.startsWith('geo-');

                return (
                  <button
                    key={`${place.id}-${idx}`}
                    type="button"
                    onMouseEnter={() => setHighlightedIndex(idx)}
                    onClick={() => handleSelect(place)}
                    className={`w-full text-left px-3.5 py-2.5 flex items-start justify-between gap-3 transition-colors ${
                      isHighlighted
                        ? 'bg-[#FAF2EE] text-[#1E1B19]'
                        : 'hover:bg-[#FAF2EE]/50 text-[#1E1B19]'
                    }`}
                  >
                    <div className="flex items-start gap-2.5 min-w-0">
                      <div className="mt-0.5 text-[#865302] shrink-0">
                        {iconType === 'origin' ? (
                          <MapPin className="w-3.5 h-3.5" />
                        ) : (
                          <Navigation className="w-3.5 h-3.5" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-[#1E1B19] flex items-center gap-1.5 truncate">
                          <span>{place.name}</span>
                          {isSelected && <Check className="w-3 h-3 text-emerald-600 shrink-0" />}
                          {isLive && (
                            <span className="px-1.5 py-0.2 rounded text-[9px] font-medium bg-emerald-50 text-emerald-800 border border-emerald-200 shrink-0">
                              Global Atlas
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-[#655D59] truncate">
                          {place.region ? `${place.region} · ` : ''}{place.country}
                        </div>
                        <div className="text-[10px] text-[#865302] mt-0.5 font-medium truncate">
                          {place.tag}
                        </div>
                      </div>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
