import type { VercelRequest, VercelResponse } from '@vercel/node';

export default function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const { hotelName, roomType, price } = req.body || {};
  const reservationId = 'ORB-' + Math.random().toString(36).substring(2, 8).toUpperCase() + '-' + Date.now().toString().slice(-4);

  return res.status(200).json({
    success: true,
    reservationId,
    hotelName: hotelName || 'Selected Sanctuary',
    roomType: roomType || 'Valley View Private Villa',
    rateLocked: price || 'Guaranteed Best Rate',
    status: 'CONFIRMED_HELD',
    guaranteeDeadline: '24 Hours Prior to Arrival with 100% Refundable terms',
    agentVerification: 'Decisive Travel Intelligence Booking Hold Verified',
    timestamp: new Date().toISOString(),
  });
}
