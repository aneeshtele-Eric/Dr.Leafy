import type { VercelRequest, VercelResponse } from '@vercel/node';
import { GoogleGenAI } from '@google/genai';

const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  try {
    ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: { 'User-Agent': 'aistudio-build' },
      },
    });
  } catch (e) {
    console.warn('Failed to initialize GoogleGenAI', e);
  }
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // Enable CORS
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  );

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const { origin, destination, dates, travelerCount, style, durationDays, rejectionFeedback, activeConstraints, previousPlan } = req.body || {};

  if (!origin || !destination) {
    return res.status(400).json({ error: 'Origin and destination are required.' });
  }

  // Try real Gemini AI if configured
  if (ai) {
    try {
      const systemInstruction = `You are "Orbit Engine", an autonomous travel and purchasing agent. Your goal is to eliminate decision fatigue by generating actionable, decisive recommendations based on traffic, real-time reviews, crowd patterns, and user preferences. Always return the plan in strict JSON format.`;

      const userPrompt = `Generate an autonomous travel plan:
Origin: ${origin}
Destination: ${destination}
Duration: ${durationDays && durationDays !== 'all' ? `${durationDays} Days` : dates || 'Upcoming weekend'}
Dates: ${dates || 'Upcoming weekend'}
Traveler Count: ${travelerCount || 2}
Preferred Style: ${style || 'Serene Retreat & Anti-Tourist Trap'}
Rejection Feedback: ${rejectionFeedback ? `USER REJECTED: "${rejectionFeedback}". ADJUST CONSTRAINTS IMMEDIATELY.` : 'None'}
Active Constraints: ${activeConstraints && activeConstraints.length > 0 ? activeConstraints.join(', ') : 'None'}`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: userPrompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          temperature: 0.7,
        },
      });

      const responseText = response.text?.trim() || '';
      const parsedPlan = JSON.parse(responseText);
      return res.status(200).json({
        source: 'gemini-ai',
        plan: parsedPlan,
      });
    } catch (err) {
      console.warn('Gemini generateContent failed, using fallback', err);
    }
  }

  // Fallback high-fidelity deterministic engine
  const defaultDist = Math.floor(180 + Math.random() * 80);
  const cleanDest = destination.split(',')[0].trim();
  const cleanOrigin = origin.split(',')[0].trim();

  const isHectic = (rejectionFeedback || '').toLowerCase().includes('hectic');
  const isResort = (rejectionFeedback || '').toLowerCase().includes('resort');
  const isDawn = (rejectionFeedback || '').toLowerCase().includes('dawn') || (rejectionFeedback || '').toLowerCase().includes('early');

  const fallbackPlan = {
    summary: isHectic
      ? `Orbit Engine Constraint Loop Active: Scaled itinerary density down by 50% for ${cleanOrigin} → ${cleanDest}. Replaced fast-paced transit with generous downtime, quiet natural sanctuaries, and verified acoustic calm.`
      : `Decisive autonomous travel blueprint from ${cleanOrigin} to ${cleanDest}. Engineered to eliminate decision fatigue with optimal departure timing, crowds avoidance, and verified high-sentiment sanctuary lodging.`,
    departure_advice: {
      recommended_time: isDawn ? '10:30 AM – 11:15 AM (Post-Rush Clear)' : '06:00 AM – 06:45 AM (Dawn Traffic Advantage)',
      route: `Direct expressway bypass arterial from ${cleanOrigin} evading central choke points towards ${cleanDest}`,
      traffic_notes: 'Departing during the recommended dawn corridor prevents urban bottleneck delays and preserves over 75 minutes of smooth travel time.',
      total_distance_km: defaultDist,
    },
    hotel_recommendation: {
      name: isResort ? `${cleanDest} Heritage Sanctuary Manor` : `${cleanDest} Private Estate & Spa`,
      rating: '4.89 / 5.0',
      best_price: '₹18,500 / night',
      provider: 'Direct Reserve / Curated Lodging',
      booking_url: `https://www.booking.com/searchresults.html?ss=${encodeURIComponent(cleanDest)}`,
      sentiment_highlight: "Verified serenity score 96%: 'Unobstructed landscape views, soundproofed architecture, and exceptional privacy away from crowded commercial hubs.'",
    },
    itinerary: [
      {
        day: 1,
        time: isDawn ? '10:45 AM' : '06:15 AM',
        activity: `Optimal Wheels-Up Departure from ${cleanOrigin}`,
        crowd_level: 'Low',
        notes: 'Clear passage before commercial morning congestion.',
      },
      {
        day: 1,
        time: '12:30 PM',
        activity: `Secluded Arrival & Botanical Tea Welcome in ${cleanDest}`,
        crowd_level: 'Low',
        notes: 'Private check-in with panoramic terrace view, zero lobby queues.',
      },
      {
        day: 1,
        time: '04:30 PM',
        activity: 'Sunset Valley Meadow Walk & Slow Dining',
        crowd_level: 'Low',
        notes: 'Unhurried locally sourced culinary feast prepared with organic regional produce.',
      },
      {
        day: 2,
        time: '08:30 AM',
        activity: 'Early Morning Nature Immersion & Regional Breakfast',
        crowd_level: 'Low',
        notes: 'Peaceful morning light before day-tripper arrival in central zones.',
      },
      {
        day: 2,
        time: '02:00 PM',
        activity: 'Dedicated 3-Hour Unstructured Downtime & Porch Serenity',
        crowd_level: 'Low',
        notes: 'Enforced quiet hours: zero mandatory waypoints; pure physical recovery.',
      },
      {
        day: 3,
        time: '10:00 AM',
        activity: `Unhurried Departure via Scenic Bypass Corridor towards ${cleanOrigin}`,
        crowd_level: 'Low',
        notes: 'Carefully timed return avoiding late-afternoon return choke points.',
      },
    ],
    alternative_quick_pivots: [
      `Shift accommodation to private secluded villa on outskirts of ${cleanDest}`,
      `Pivot route to scenic highland country pass`,
      `Extend downtime ratio to 70% unstructured relaxation`,
    ],
    seasonal_dynamics: {
      date_classification: durationDays === 1 ? 'Single-Day Escape' : 'Weekend Leisure Rush',
      rush_factor: 'High',
      price_impact: '+28% Weekend Peak Demand Active',
      reasoning: 'Selected dates fall on peak recreational windows: arterial expressways experience departure tolls surge.',
    },
  };

  return res.status(200).json({
    source: 'engine-offline',
    plan: fallbackPlan,
  });
}
