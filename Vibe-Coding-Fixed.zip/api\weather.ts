import type { VercelRequest, VercelResponse } from '@vercel/node';

function interpretWmoCode(code: number): { condition: string; icon: string; comfort: string } {
  switch (code) {
    case 0:
      return { condition: 'Clear Blue Skies', icon: 'sun', comfort: 'Crisp & Sunny · Optimal Sightlines' };
    case 1:
      return { condition: 'Mainly Clear & Crisp', icon: 'sun', comfort: 'Optimal Mountain Vista' };
    case 2:
      return { condition: 'Partly Cloudy & Pleasant', icon: 'cloud-sun', comfort: 'Gentle Highland Canopy' };
    case 3:
      return { condition: 'Overcast & Cool', icon: 'cloud', comfort: 'Cool Shading · Low UV' };
    case 45:
    case 48:
      return { condition: 'Morning Mountain Mist / Fog', icon: 'cloud-fog', comfort: 'Atmospheric Fog · Daytime Clears' };
    case 51:
    case 53:
    case 55:
      return { condition: 'Light Plantation Drizzle', icon: 'cloud-drizzle', comfort: 'Fresh Aromatic Showers' };
    case 61:
    case 63:
    case 65:
      return { condition: 'Highland Rain Showers', icon: 'cloud-rain', comfort: 'Wet Ghats Roadways · Drive Deliberately' };
    case 80:
    case 81:
    case 82:
      return { condition: 'Passing Scattered Showers', icon: 'cloud-rain', comfort: 'Intermittent Showers' };
    case 95:
    case 96:
    case 99:
      return { condition: 'Afternoon Mountain Thunderstorm', icon: 'cloud-lightning', comfort: 'Indoor Estate Relaxation Recommended' };
    default:
      return { condition: 'Fair Mountain Air', icon: 'cloud-sun', comfort: 'Pleasant Highland Climate' };
  }
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const destinationQuery = (req.query.destination as string) || 'Coorg, KA';
  const cleanName = destinationQuery.split(',')[0].replace(/\(.*?\)/g, '').trim();

  let lat = 12.426;
  let lon = 75.738;
  let elevation = 1140;
  let resolvedName = destinationQuery;

  try {
    const geoResp = await fetch(
      `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(cleanName)}&count=1&language=en&format=json`
    );
    if (geoResp.ok) {
      const geoJson = await geoResp.json();
      if (geoJson.results && geoJson.results.length > 0) {
        const r = geoJson.results[0];
        lat = r.latitude;
        lon = r.longitude;
        elevation = Math.round(r.elevation || 850);
        resolvedName = `${r.name}${r.admin1 ? `, ${r.admin1}` : ''}, ${r.country || ''}`;
      }
    }
  } catch {}

  try {
    const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,uv_index_max,wind_speed_10m_max&hourly=temperature_2m,relative_humidity_2m,precipitation_probability,weather_code&timezone=auto`;
    const response = await fetch(weatherUrl);

    if (response.ok) {
      const json = await response.json();
      const current = json.current || {};
      const daily = json.daily || {};
      const hourly = json.hourly || {};
      const currentWmo = interpretWmoCode(current.weather_code || 0);

      const datesCount = (daily.time || []).length;
      const dailyItems = [];
      for (let i = 0; i < Math.min(datesCount, 7); i++) {
        const dateStr = daily.time[i];
        const dObj = new Date(dateStr + 'T00:00:00');
        const dayLabel = dObj.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
        const wCode = daily.weather_code?.[i] || 0;
        const wInfo = interpretWmoCode(wCode);

        dailyItems.push({
          date: dateStr,
          dayLabel,
          weatherCode: wCode,
          condition: wInfo.condition,
          icon: wInfo.icon,
          tempMax: Math.round(daily.temperature_2m_max?.[i] ?? 24),
          tempMin: Math.round(daily.temperature_2m_min?.[i] ?? 16),
          precipitationProbability: Math.round(daily.precipitation_probability_max?.[i] ?? 10),
          uvIndexMax: Math.round(daily.uv_index_max?.[i] ?? 5),
          windSpeedMax: Math.round(daily.wind_speed_10m_max?.[i] ?? 12),
          comfortNote: wInfo.comfort,
        });
      }

      const hourlyList = [];
      const targetHours = [6, 9, 12, 15, 18, 21];
      const hTimes = hourly.time || [];
      for (const th of targetHours) {
        const idx = hTimes.findIndex((t: string) => t.includes(`T${th.toString().padStart(2, '0')}:00`));
        if (idx !== -1) {
          const hCode = hourly.weather_code?.[idx] ?? 0;
          const hInfo = interpretWmoCode(hCode);
          hourlyList.push({
            time: th < 12 ? `${th}:00 AM` : th === 12 ? '12:00 PM' : `${th - 12}:00 PM`,
            temp: Math.round(hourly.temperature_2m?.[idx] ?? 20),
            weatherCode: hCode,
            condition: hInfo.condition,
            icon: hInfo.icon,
            rainProb: Math.round(hourly.precipitation_probability?.[idx] ?? 5),
            humidity: Math.round(hourly.relative_humidity_2m?.[idx] ?? 70),
          });
        }
      }

      return res.status(200).json({
        destination: destinationQuery,
        resolvedName,
        elevationMeters: elevation,
        microclimateType: `${cleanName} Atmospheric Microclimate`,
        coordinates: { latitude: lat, longitude: lon },
        current: {
          temperature: Math.round(current.temperature_2m ?? 21),
          apparentTemperature: Math.round(current.apparent_temperature ?? 20),
          humidity: Math.round(current.relative_humidity_2m ?? 72),
          precipitation: current.precipitation ?? 0,
          windSpeed: Math.round(current.wind_speed_10m ?? 10),
          weatherCode: current.weather_code ?? 0,
          condition: currentWmo.condition,
          icon: currentWmo.icon,
          isDay: current.is_day === 1,
          uvIndex: daily.uv_index_max?.[0] ?? 4,
          visibilityKm: (current.weather_code === 45 || current.weather_code === 48) ? 4.5 : 10,
          comfortCategory: currentWmo.comfort,
          updatedAt: new Date().toISOString(),
        },
        daily: dailyItems,
        hourlyPreview: hourlyList,
        travelAdvisory: {
          drivingVisibility: (current.weather_code === 45 || current.weather_code === 48)
            ? 'Morning valley fog between 05:45 – 08:30 AM; reduce speed on hairpin curves'
            : 'Optimal visibility across all roads and mountain passes (> 10 km)',
          roadGrip: (current.precipitation > 0 || (daily.precipitation_probability_max?.[0] ?? 0) > 40)
            ? 'Damp road surface in sheltered forest bends; maintain standard 3-second braking buffer'
            : 'Dry, optimal tarmac grip with minimal hydroplaning risk',
          packingAdvice: [
            'Light breathable layers for sunny midday hours',
            'Warm fleece or shawl for crisp dawn & twilight temperatures',
            'Comfortable treaded footwear for plantation walks',
            'Compact umbrella or water-resistant shell'
          ],
          idealOutdoorHours: '06:30 AM – 10:30 AM & 04:00 PM – 06:30 PM (Golden twilight serenity)',
          microclimateNotice: `${cleanName} features an elevation of ~${elevation}m, with rapid evening cooldowns.`,
        },
        source: 'live_open_meteo',
      });
    }
  } catch (err) {
    return res.status(500).json({ error: 'Failed to retrieve weather intelligence.' });
  }

  return res.status(500).json({ error: 'Failed to retrieve weather intelligence.' });
}
